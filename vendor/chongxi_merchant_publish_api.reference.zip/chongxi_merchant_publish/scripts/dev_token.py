import argparse
from datetime import datetime, timedelta, timezone
import jwt
from app.config import settings

parser = argparse.ArgumentParser(description="仅本地开发使用：生成测试 JWT")
parser.add_argument("--user-id", type=int, required=True)
args = parser.parse_args()
if args.user_id <= 0:
    parser.error("user-id必须为正整数")
print(jwt.encode({"sub": str(args.user_id), "exp": datetime.now(timezone.utc) + timedelta(hours=2)}, settings.jwt_secret, algorithm=settings.jwt_algorithm))
