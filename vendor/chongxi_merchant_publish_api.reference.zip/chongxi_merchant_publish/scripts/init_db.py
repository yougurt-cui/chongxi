from app.database import Base, engine
from app import models  # noqa: F401  注册全部表

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    print("数据库表已创建（已存在的表不会修改）")
