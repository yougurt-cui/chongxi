from sqlalchemy import select
from app.database import SessionLocal
from app.models import User, MerchantAccount

# 仅供本地联调：创建认证商家，不要在生产环境运行
with SessionLocal() as db:
    user = db.scalar(select(User).where(User.nickname == "宠析演示博主"))
    if not user:
        user = User(nickname="宠析演示博主")
        db.add(user)
        db.flush()
    merchant = db.scalar(select(MerchantAccount).where(MerchantAccount.user_id == user.id))
    if not merchant:
        merchant = MerchantAccount(user_id=user.id, merchant_name="宠析演示商家", merchant_type="merchant", status="approved")
        db.add(merchant)
    db.commit()
    print(f"演示 user_id={user.id}；merchant_id={merchant.id}；认证状态={merchant.status}")
