import io
import os
import tempfile
from pathlib import Path
from datetime import datetime, timedelta, timezone

# 必须在导入应用前设置环境变量
os.environ["DATABASE_URL"] = "sqlite://"
os.environ["JWT_SECRET"] = "unit_test_secret_only_not_for_production_1234"
os.environ["UPLOAD_DIR"] = tempfile.mkdtemp(prefix="cx_test_upload_")

import jwt
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.pool import StaticPool
from sqlalchemy.orm import sessionmaker
from PIL import Image
from app.database import Base, get_db
from app.models import User, MerchantAccount, MerchantProduct, CommunityPost, PostProductRelation
from app.main import app

engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
TestingSession = sessionmaker(bind=engine, expire_on_commit=False)
Base.metadata.create_all(engine)


def override_db():
    with TestingSession() as db:
        yield db

app.dependency_overrides[get_db] = override_db
client = TestClient(app)


def token(user_id):
    return jwt.encode({"sub": str(user_id), "exp": datetime.now(timezone.utc) + timedelta(hours=1)}, os.environ["JWT_SECRET"], algorithm="HS256")


def auth(user_id):
    return {"Authorization": "Bearer " + token(user_id)}


def test_publish_flow_and_permission():
    with TestingSession() as db:
        approved = User(nickname="博主A")
        ordinary = User(nickname="普通用户B")
        db.add_all([approved, ordinary]); db.flush()
        db.add(MerchantAccount(user_id=approved.id, merchant_name="商家A", status="approved", merchant_type="merchant"))
        db.commit()
        aid, bid = approved.id, ordinary.id

    picture = Image.new("RGB", (2, 2))
    buf = io.BytesIO(); picture.save(buf, format="PNG")
    uploaded = client.post("/api/images/upload", files={"file": ("p.png", buf.getvalue(), "image/png")}, headers=auth(aid))
    assert uploaded.status_code == 201, uploaded.text
    image_id = uploaded.json()["data"]["image_id"]
    body = {"image_ids": [image_id], "product_name": "冻干", "product_content": "介绍", "product_price": "39.90"}
    assert client.post("/api/merchant/products/publish", json=body).status_code == 401
    assert client.post("/api/merchant/products/publish", json=body, headers=auth(bid)).status_code == 403
    result = client.post("/api/merchant/products/publish", json=body, headers=auth(aid))
    assert result.status_code == 201, result.text
    data = result.json()["data"]
    assert data["user_id"] == aid and data["post_id"] > 0
    with TestingSession() as db:
        assert db.scalar(select(MerchantProduct).where(MerchantProduct.product_id == data["product_id"]))
        assert db.scalar(select(CommunityPost).where(CommunityPost.id == data["post_id"]))
        assert db.scalar(select(PostProductRelation).where(PostProductRelation.post_id == data["post_id"]))
    detail = client.get("/api/merchant/products/" + data["product_id"])
    assert detail.status_code == 200
    assert detail.json()["data"]["product_price"] == "39.90"
    mine = client.get("/api/merchant/products/mine", headers=auth(aid))
    assert mine.json()["data"]["total"] == 1
    bad_img = client.post("/api/merchant/products/publish", json={**body, "image_ids": [999999]}, headers=auth(aid))
    assert bad_img.status_code == 400
