# 宠析商家商品发布 API（完整示例）

此项目提供：JWT 登录态读取博主 `user_id`、认证商家身份查询、商品图片上传并获取 `image_id`、商品 SKU 发布、自动生成社区帖子、关联表、我的商品列表、商品详情。

## 1. 快速启动（Python 3.10+）

```bash
cd chongxi_merchant_publish
python -m venv .venv
source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # Windows 可以直接复制文件
python -m scripts.init_db
python -m scripts.seed_demo
# 上一条会打印演示 user_id，例如 1，按实际输出替换
python -m scripts.dev_token --user-id 1
uvicorn app.main:app --reload --port 8000
```

访问 http://127.0.0.1:8000/docs 使用 Swagger 接口文档。开发环境 SQLite 开箱即用，部署时可更换 MySQL。

## 2. 发布步骤

1. 用 `Authorization: Bearer <token>` 调用 `POST /api/images/upload`（form-data，字段名 `file`），每张上传返回 `data.image_id`。
2. 使用图片 ID 列表请求 `POST /api/merchant/products/publish`：

```json
{
  "image_ids": [1, 2],
  "product_name": "手工冻干鸡胸肉",
  "product_content": "精选鸡胸肉，低温冻干",
  "product_price": "39.90"
}
```

注意：示例 `1,2` 必须替换为实际已上传的、属于当前博主的图片 ID。成功返回 HTTP 201，`code=0`、`product_id`、`post_id`、`user_id`、`merchant_id`。

另外提供：
- `GET /api/merchant/products/mine?page=1&page_size=20`（登录后的博主商品列表）
- `GET /api/merchant/products/{product_id}`（已发布商品详情）
- `GET /health`（健康检查）

## 3. 数据库结构

- `cx_user`: 示例用户表，**接入现有系统时使用你们真实的用户表**
- `merchant_account`: 一个用户对应一个认证商家（demo 设计），商家身份 `status='approved'`
- `uploaded_image`: 图片元数据及图片拥有者
- `merchant_product`: SKU、图片 ID、内容、价格、`user_id`、`merchant_id`
- `community_post`: 社区帖子，商品帖类型为 `product`
- `post_product_relation`: 多帖子可关联同一 SKU，唯一键 `(post_id, product_id)`

启动脚本采用 SQLAlchemy `create_all` 建新表；**不会迁移已有表**。如果现有数据库已含同名表，先比对字段后做版本化迁移，不要直接执行；建议使用 Alembic。

## 4. 生产接入注意事项

1. **认证**：当前 JWT 校验是独立示例。若现有小程序登录态使用其他 Token 或 session，替换 `app/auth.py` 的 `get_current_user_id`，不可信任前端传入的 user_id。
2. **商家表**：按照既有认证系统适配 `merchant_account` 的字段及状态；禁止由客户端自助将 `approved` 设为真。
3. **帖子表**：若已有社区帖子库，改用现有字段/发帖服务。若发帖服务不与商品表共库，不能直接跨库事务，需 outbox/异步补偿机制。
4. **图片存储**：本示例将图片保存在本地 `uploads/`，且静态目录可被公开访问。上线建议改用 OSS 对象存储、内容审核、访问策略和图像尺寸/压缩限制。
5. **内容合规**：示例未对商品内容进行审核，`published` 为直接发布；生产应结合平台审核流程设置 `pending_review` 等状态，审核后再上架。
6. **运行**：将 `.env` 加入忽略列表，使用强 JWT 密钥和 HTTPS。需要处理频率限制、重复提交、上传垃圾清理、日志监控及数据库备份。
7. **货币精度**：价格按十进制字符串（例如 `"39.90"`）传入以避免浮点误差。
8. **账号模型**：demo 规定一个博主只有一个认证商家；如同一用户管理多个商家，需要调整授权关联表及发布时的商家选择流程。

## 5. 运行自动化测试

```bash
pytest -q
```

测试覆盖：未登录、非商家、图片归属校验、商品+帖子+关联写入、商品详情、我的商品列表。

## 6. 项目文件说明

```
app/config.py          环境变量配置
app/database.py        数据库连接
app/models.py          6张表 ORM
app/schemas.py         发布请求校验
app/auth.py            JWT 登录校验
app/main.py            上传/发布/列表/详情 API
scripts/init_db.py     建表
scripts/seed_demo.py   创建演示认证商家
scripts/dev_token.py   生成本地测试 Token
examples/miniprogram.js 微信小程序对接示例
tests/test_publish.py  接口测试
Dockerfile             容器启动示例
```
