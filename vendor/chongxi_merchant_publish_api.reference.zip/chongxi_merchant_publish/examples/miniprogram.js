// 微信小程序示例：先调用上传接口获取 image_id，再发布商品
// BASE_URL 必须是已配置的 HTTPS 合法域名。token 由宠析现有登录系统签发。
const BASE_URL = 'https://你的接口域名';
const token = wx.getStorageSync('token');

function publishProduct(imageIds) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: `${BASE_URL}/api/merchant/products/publish`,
      method: 'POST',
      header: { Authorization: `Bearer ${token}` },
      data: {
        image_ids: imageIds,
        product_name: '手工冻干鸡胸肉',
        product_content: '精选鸡胸肉，低温冻干',
        product_price: '39.90'
      },
      success: (res) => {
        if (res.statusCode === 201 && res.data.code === 0) {
          resolve(res.data.data);
        } else {
          reject(new Error(res.data.detail || '发布失败'));
        }
      },
      fail: reject
    });
  });
}

// 对每张选中的本地图片执行：
// wx.uploadFile({ url: BASE_URL + '/api/images/upload', filePath, name: 'file',
//   header: { Authorization: 'Bearer ' + token }, success: ({data}) => {
//     const imageId = JSON.parse(data).data.image_id;
//     // 收集图片ID后调用 publishProduct(imageIds)
//   } })
