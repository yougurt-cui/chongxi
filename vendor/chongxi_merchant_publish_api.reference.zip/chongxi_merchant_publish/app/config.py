from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str = "sqlite:///./chongxi.db"
    jwt_secret: str
    jwt_algorithm: str = "HS256"
    upload_dir: Path = Path("./uploads")
    max_image_bytes: int = 5 * 1024 * 1024

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
