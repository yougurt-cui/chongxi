from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import BigInteger, DateTime, ForeignKey, Index, Integer, JSON, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


# Integer主键可兼容 SQLite 测试与 MySQL bigint
PK = BigInteger().with_variant(Integer, "sqlite")


class User(Base):
    __tablename__ = "cx_user"
    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    nickname: Mapped[str] = mapped_column(String(100), nullable=False)


class MerchantAccount(Base):
    __tablename__ = "merchant_account"
    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("cx_user.id"), nullable=False, unique=True)
    merchant_name: Mapped[str] = mapped_column(String(200), nullable=False)
    merchant_type: Mapped[str] = mapped_column(String(32), nullable=False, default="merchant")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")


class UploadedImage(Base):
    __tablename__ = "uploaded_image"
    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("cx_user.id"), nullable=False, index=True)
    storage_path: Mapped[str] = mapped_column(String(500), nullable=False)
    content_type: Mapped[str] = mapped_column(String(60), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class MerchantProduct(Base):
    __tablename__ = "merchant_product"
    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    product_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("cx_user.id"), nullable=False, index=True)
    merchant_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("merchant_account.id"), nullable=False, index=True)
    image_ids: Mapped[list] = mapped_column(JSON, nullable=False)
    product_name: Mapped[str] = mapped_column(String(200), nullable=False)
    product_content: Mapped[str] = mapped_column(Text, nullable=False)
    product_price: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="published")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)


class CommunityPost(Base):
    __tablename__ = "community_post"
    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("cx_user.id"), nullable=False, index=True)
    post_type: Mapped[str] = mapped_column(String(20), nullable=False, default="normal")
    content: Mapped[str] = mapped_column(Text, nullable=False)
    image_ids: Mapped[list] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class PostProductRelation(Base):
    __tablename__ = "post_product_relation"
    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    post_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("community_post.id"), nullable=False)
    product_id: Mapped[str] = mapped_column(String(64), ForeignKey("merchant_product.product_id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    __table_args__ = (UniqueConstraint("post_id", "product_id", name="uk_post_product"), Index("idx_relation_product", "product_id"))
