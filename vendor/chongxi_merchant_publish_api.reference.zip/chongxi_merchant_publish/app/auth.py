from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from .config import settings

bearer = HTTPBearer(auto_error=False)


def get_current_user_id(creds: HTTPAuthorizationCredentials | None = Depends(bearer)) -> int:
    if not creds:
        raise HTTPException(status_code=401, detail="未登录")
    try:
        payload = jwt.decode(creds.credentials, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
        subject = payload.get("sub")
        if not isinstance(subject, str) or not subject.isdigit() or int(subject) <= 0:
            raise ValueError("bad sub")
        return int(subject)
    except (jwt.InvalidTokenError, ValueError):
        raise HTTPException(status_code=401, detail="Token无效或过期")
