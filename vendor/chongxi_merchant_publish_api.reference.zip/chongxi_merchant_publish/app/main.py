import io
import uuid
from pathlib import Path
from decimal import Decimal

from fastapi import Depends, FastAPI, File, HTTPException, UploadFile, status
from fastapi.staticfiles import StaticFiles
from PIL import Image, UnidentifiedImageError
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from .auth import get_current_user_id
from .config import settings
from .database import get_db
from .models import MerchantAccount, UploadedImage, MerchantProduct, CommunityPost, PostProductRelation
from .schemas import ProductPublishRequest

app = FastAPI(title="宠析商家商品发布 API", version="1.0.0")
settings.upload_dir.mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(settings.upload_dir)), name="uploads")


def success(data, message="操作成功"):
    return {"code": 0, "message": message, "data": data}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/images/upload", status_code=201)
async def upload_image(
    file: UploadFile = File(...),
    user_id: int = Depends(get_current_user_id),
    db: Session = Depends(get_db),
):
    # 示例本地存储；生产建议接对象存储并设置私有权限/访问策略。
    raw = await file.read(settings.max_image_bytes + 1)
    if not raw or len(raw) > settings.max_image_bytes:
        raise HTTPException(400, "图片为空或超过大小限制")
    try:
        im = Image.open(io.BytesIO(raw))
        fmt = im.format
        im.verify()
    except (UnidentifiedImageError, OSError, ValueError):
        raise HTTPException(400, "文件不是有效图片")
    if fmt not in {"JPEG", "PNG", "WEBP"}:
        raise HTTPException(400, "仅支持 JPG、PNG、WEBP")
    ext = {"JPEG": "jpg", "PNG": "png", "WEBP": "webp"}[fmt]
    content_type = {"jpg": "image/jpeg", "png": "image/png", "webp": "image/webp"}[ext]
    filename = f"{uuid.uuid4().hex}.{ext}"
    saved_path = settings.upload_dir / filename
    try:
        saved_path.write_bytes(raw)
        image = UploadedImage(user_id=user_id, storage_path=filename, content_type=content_type)
        db.add(image)
        db.commit()
        db.refresh(image)
    except Exception:
        db.rollback()
        saved_path.unlink(missing_ok=True)
        raise HTTPException(500, "图片保存失败")
    return success({"image_id": image.id, "url": f"/uploads/{filename}"}, "图片上传成功")


@app.post("/api/merchant/products/publish", status_code=201)
def publish_product(
    body: ProductPublishRequest,
    user_id: int = Depends(get_current_user_id),
    db: Session = Depends(get_db),
):
    merchant = db.scalar(select(MerchantAccount).where(
        MerchantAccount.user_id == user_id,
        MerchantAccount.status == "approved",
    ))
    if merchant is None:
        raise HTTPException(403, "尚未通过商家认证")

    # 一次性校验全部图片ID确实由当前博主上传
    images = db.scalars(select(UploadedImage.id).where(
        UploadedImage.user_id == user_id,
        UploadedImage.id.in_(body.image_ids),
    )).all()
    if len(images) != len(body.image_ids):
        raise HTTPException(400, "部分图片ID不存在或不属于当前用户")

    product_id = "SKU" + uuid.uuid4().hex.upper()
    try:
        product = MerchantProduct(
            product_id=product_id, user_id=user_id, merchant_id=merchant.id,
            image_ids=body.image_ids, product_name=body.product_name,
            product_content=body.product_content, product_price=body.product_price,
            status="published",
        )
        db.add(product)
        post = CommunityPost(
            user_id=user_id, post_type="product", content=body.product_content,
            image_ids=body.image_ids,
        )
        db.add(post)
        db.flush()  # 取得数据库生成的 post.id
        db.add(PostProductRelation(post_id=post.id, product_id=product_id))
        db.commit()  # SKU、帖子、关联同时成功或回滚
    except Exception:
        db.rollback()
        raise HTTPException(500, "商品发布失败")

    return success({
        "product_id": product_id, "post_id": post.id,
        "user_id": user_id, "merchant_id": merchant.id,
        "status": "published",
    }, "商品发布成功")


def product_json(product, post_id):
    return {
        "product_id": product.product_id,
        "post_id": post_id,
        "user_id": product.user_id,
        "merchant_id": product.merchant_id,
        "image_ids": product.image_ids,
        "product_name": product.product_name,
        "product_content": product.product_content,
        "product_price": str(product.product_price),
        "status": product.status,
        "created_at": product.created_at.isoformat() + "Z",
    }


@app.get("/api/merchant/products/mine")
def list_my_products(
    page: int = 1, page_size: int = 20,
    user_id: int = Depends(get_current_user_id),
    db: Session = Depends(get_db),
):
    if page < 1 or not 1 <= page_size <= 100:
        raise HTTPException(422, "分页参数不合法")
    total = db.scalar(select(func.count()).select_from(MerchantProduct).where(MerchantProduct.user_id == user_id))
    records = db.execute(
        select(MerchantProduct, PostProductRelation.post_id)
        .outerjoin(PostProductRelation, PostProductRelation.product_id == MerchantProduct.product_id)
        .where(MerchantProduct.user_id == user_id)
        .order_by(MerchantProduct.created_at.desc(), MerchantProduct.id.desc())
        .limit(page_size).offset((page - 1) * page_size)
    ).all()
    return success({"total": total, "page": page, "page_size": page_size,
                    "items": [product_json(p, post_id) for p, post_id in records]})


@app.get("/api/merchant/products/{product_id}")
def product_detail(product_id: str, db: Session = Depends(get_db)):
    result = db.execute(
        select(MerchantProduct, PostProductRelation.post_id)
        .outerjoin(PostProductRelation, PostProductRelation.product_id == MerchantProduct.product_id)
        .where(MerchantProduct.product_id == product_id, MerchantProduct.status == "published")
    ).first()
    if result is None:
        raise HTTPException(404, "商品不存在或未发布")
    return success(product_json(result[0], result[1]))
