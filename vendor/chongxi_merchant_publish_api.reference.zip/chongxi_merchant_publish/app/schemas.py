from decimal import Decimal
from pydantic import BaseModel, ConfigDict, Field, field_validator


class ProductPublishRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    image_ids: list[int] = Field(min_length=1, max_length=9)
    product_name: str = Field(min_length=1, max_length=200)
    product_content: str = Field(min_length=1, max_length=20000)
    product_price: Decimal = Field(ge=0, max_digits=10, decimal_places=2)

    @field_validator("image_ids")
    @classmethod
    def image_ids_valid(cls, ids):
        if any(i <= 0 for i in ids) or len(ids) != len(set(ids)):
            raise ValueError("图片ID必须为正整数且不可重复")
        return ids

    @field_validator("product_name", "product_content")
    @classmethod
    def nonblank(cls, value):
        value = value.strip()
        if not value:
            raise ValueError("内容不能为空")
        return value
